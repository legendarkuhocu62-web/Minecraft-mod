package dev.expressions;

import java.util.UUID;

/** Мост: кладём UUID игрока в AvatarRenderState, чтобы в момент отрисовки знать, чьё это тело. */
public interface ExprHolder {
    void expr$setUuid(UUID uuid);
    UUID expr$getUuid();
}
