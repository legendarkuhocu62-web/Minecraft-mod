package dev.expressions;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Хранит выражения: собирает из base.png (твой скин) + маленьких PNG-накладок лица,
 * регистрирует готовые текстуры и говорит рендеру, какую подставить.
 */
public final class ExpressionManager {
    private ExpressionManager() {}

    public static final List<String> NAMES = List.of("neutral", "happy", "sad", "surprised", "scared", "angry");
    private static final Map<String, String> RU = Map.of(
        "neutral", "обычное", "happy", "радость", "sad", "грусть",
        "surprised", "удивление", "scared", "страх", "angry", "злость");
    private static final String[] TEMPLATES = {"happy", "sad", "surprised", "scared", "angry", "blink"};

    private static final Map<String, Identifier> textures = new HashMap<>();
    private static boolean ready = false;
    private static boolean warnedNoBase = false;
    private static boolean firstLoadTried = false;

    private static int current = 0;
    private static boolean autoBlink = true;
    private static int blinkMin = 50, blinkMax = 160, blinkDuration = 3;
    private static int[][] eyes = {{9, 12, 2, 1}, {13, 12, 2, 1}};
    private static int blinkWait = 60;
    private static int blinkRemaining = 0;
    private static final Random RNG = new Random();

    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("expressions");
    }

    // ------------------------------------------------------------ управление

    public static void tick(Minecraft mc) {
        if (mc.player == null) return;
        if (!firstLoadTried) {
            firstLoadTried = true;
            reload(mc);
        }
        if (!ready) return;
        if (blinkRemaining > 0) {
            blinkRemaining--;
        } else if (autoBlink) {
            if (--blinkWait <= 0) {
                blinkRemaining = blinkDuration;
                blinkWait = blinkMin + RNG.nextInt(Math.max(1, blinkMax - blinkMin + 1));
            }
        }
    }

    public static void set(Minecraft mc, String name) {
        int idx = NAMES.indexOf(name);
        if (idx < 0) return;
        current = idx;
        announce(mc);
    }

    public static void cycle(Minecraft mc, int dir) {
        current = Math.floorMod(current + dir, NAMES.size());
        announce(mc);
    }

    public static void blinkNow() {
        blinkRemaining = blinkDuration + 1;
    }

    public static void toggleAutoBlink(Minecraft mc) {
        autoBlink = !autoBlink;
        message(mc, "Авто-моргание: " + (autoBlink ? "включено" : "выключено"));
    }

    private static void announce(Minecraft mc) {
        message(mc, "Выражение: " + RU.get(NAMES.get(current)));
        if (!ready) message(mc, "Нет base.png в config/expressions/ — положи туда свой скин 64x64");
    }

    private static void message(Minecraft mc, String text) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(text), true);
    }

    /** Вызывается рендером: какую текстуру показать для этого игрока (null = не трогать). */
    public static Identifier textureFor(UUID uuid) {
        if (!ready || uuid == null) return null;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !uuid.equals(mc.player.getUUID())) return null;
        String name = NAMES.get(current);
        return textures.get(blinkRemaining > 0 ? name + "_blink" : name);
    }

    // ------------------------------------------------------------ загрузка

    public static void reload(Minecraft mc) {
        try {
            Path dir = dir();
            Files.createDirectories(dir);
            copyTemplates(dir);
            readConfig(dir.resolve("config.json"));

            Path basePath = dir.resolve("base.png");
            if (!Files.exists(basePath)) {
                ready = false;
                if (!warnedNoBase) {
                    warnedNoBase = true;
                    ExpressionsMod.LOGGER.warn("Нет {} — положи туда свой скин (PNG 64x64).", basePath);
                }
                message(mc, "Положи свой скин в config/expressions/base.png");
                return;
            }

            NativeImage base;
            try (InputStream in = Files.newInputStream(basePath)) {
                base = NativeImage.read(in);
            }
            if (base.getWidth() != 64 || base.getHeight() != 64) {
                ExpressionsMod.LOGGER.warn("base.png должен быть 64x64, а он {}x{}", base.getWidth(), base.getHeight());
                message(mc, "base.png должен быть 64x64");
                base.close();
                ready = false;
                return;
            }

            TextureManager tm = mc.getTextureManager();
            for (Identifier id : textures.values()) tm.release(id);
            textures.clear();

            NativeImage blinkPatch = readPatch(dir.resolve("blink.png"));
            for (String name : NAMES) {
                NativeImage open = copy(base);
                if (!name.equals("neutral")) {
                    NativeImage patch = readPatch(dir.resolve(name + ".png"));
                    if (patch != null) {
                        applyPatch(open, patch);
                        patch.close();
                    }
                }
                NativeImage closed = copy(open);
                if (blinkPatch != null) applyPatch(closed, blinkPatch); else proceduralBlink(closed);

                register(tm, name, open);
                register(tm, name + "_blink", closed);
            }
            if (blinkPatch != null) blinkPatch.close();
            base.close();

            ready = true;
            message(mc, "Выражения загружены");
            ExpressionsMod.LOGGER.info("Выражения загружены: {}", textures.keySet());
        } catch (Exception e) {
            ready = false;
            ExpressionsMod.LOGGER.error("Не удалось загрузить выражения", e);
            message(mc, "Ошибка загрузки выражений, смотри лог");
        }
    }

    private static void register(TextureManager tm, String name, NativeImage image) {
        Identifier id = Identifier.fromNamespaceAndPath(ExpressionsMod.MOD_ID, "dyn/" + name);
        tm.register(id, new DynamicTexture(() -> "expressions_" + name, image));
        textures.put(name, id);
    }

    private static NativeImage copy(NativeImage src) {
        NativeImage out = new NativeImage(src.getWidth(), src.getHeight(), false);
        for (int y = 0; y < src.getHeight(); y++)
            for (int x = 0; x < src.getWidth(); x++)
                out.setPixel(x, y, src.getPixel(x, y));
        return out;
    }

    private static NativeImage readPatch(Path path) throws IOException {
        if (!Files.exists(path)) return null;
        try (InputStream in = Files.newInputStream(path)) {
            return NativeImage.read(in);
        }
    }

    /**
     * Накладка 8x8 ложится на лицо (x=8, y=8 в скине). Накладка 64x64 накладывается на весь скин.
     * Прозрачные пиксели накладки не трогают скин.
     */
    private static void applyPatch(NativeImage dst, NativeImage patch) {
        int ox = 0, oy = 0;
        if (patch.getWidth() == 8 && patch.getHeight() == 8) { ox = 8; oy = 8; }
        for (int y = 0; y < patch.getHeight(); y++) {
            for (int x = 0; x < patch.getWidth(); x++) {
                int p = patch.getPixel(x, y);
                if ((p >>> 24) == 0) continue;
                int tx = x + ox, ty = y + oy;
                if (tx < dst.getWidth() && ty < dst.getHeight()) dst.setPixel(tx, ty, p);
            }
        }
    }

    /** Если blink.png нет: закрываем глаза цветом кожи из пикселей под глазами + тёмная линия ресниц. */
    private static void proceduralBlink(NativeImage img) {
        for (int[] e : eyes) {
            int x0 = e[0], y0 = e[1], w = e[2], h = e[3];
            for (int i = 0; i < w; i++) {
                int below = img.getPixel(x0 + i, y0 + h);
                for (int j = 0; j < h; j++) img.setPixel(x0 + i, y0 + j, below);
                img.setPixel(x0 + i, y0 + h - 1, darken(below));
            }
        }
    }

    private static int darken(int p) {
        int a = p & 0xFF000000;
        int c0 = (int) ((p & 0xFF) * 0.55);
        int c1 = (int) (((p >> 8) & 0xFF) * 0.55);
        int c2 = (int) (((p >> 16) & 0xFF) * 0.55);
        return a | (c2 << 16) | (c1 << 8) | c0;
    }

    private static void readConfig(Path file) throws IOException {
        if (!Files.exists(file)) {
            Files.writeString(file, """
                {
                  "autoBlink": true,
                  "blinkMinTicks": 50,
                  "blinkMaxTicks": 160,
                  "blinkDurationTicks": 3,
                  "eyes": [[9, 12, 2, 1], [13, 12, 2, 1]]
                }
                """);
        }
        try (Reader r = Files.newBufferedReader(file)) {
            JsonObject o = JsonParser.parseReader(r).getAsJsonObject();
            if (o.has("autoBlink")) autoBlink = o.get("autoBlink").getAsBoolean();
            if (o.has("blinkMinTicks")) blinkMin = o.get("blinkMinTicks").getAsInt();
            if (o.has("blinkMaxTicks")) blinkMax = o.get("blinkMaxTicks").getAsInt();
            if (o.has("blinkDurationTicks")) blinkDuration = o.get("blinkDurationTicks").getAsInt();
            if (o.has("eyes")) {
                JsonArray arr = o.getAsJsonArray("eyes");
                int[][] list = new int[arr.size()][4];
                for (int i = 0; i < arr.size(); i++) {
                    JsonArray a = arr.get(i).getAsJsonArray();
                    for (int k = 0; k < 4; k++) {
                        JsonElement el = a.get(k);
                        list[i][k] = el.getAsInt();
                    }
                }
                eyes = list;
            }
        }
    }

    private static void copyTemplates(Path dir) {
        for (String name : TEMPLATES) {
            Path target = dir.resolve(name + ".png");
            if (Files.exists(target)) continue;
            String res = "/assets/" + ExpressionsMod.MOD_ID + "/templates/" + name + ".png";
            try (InputStream in = ExpressionManager.class.getResourceAsStream(res)) {
                if (in != null) Files.copy(in, target);
            } catch (IOException e) {
                ExpressionsMod.LOGGER.warn("Не удалось скопировать шаблон {}", name, e);
            }
        }
    }
}
