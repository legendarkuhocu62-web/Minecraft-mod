package dev.expressions;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;

public class ExpressionsMod implements ClientModInitializer {
    public static final String MOD_ID = "expressions";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyMapping key(String name, int code, KeyMapping.Category category) {
        return KeyBindingHelper.registerKeyBinding(
            new KeyMapping("key." + MOD_ID + "." + name, InputConstants.Type.KEYSYM, code, category)
        );
    }

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));

        KeyMapping next = key("next", GLFW.GLFW_KEY_RIGHT_BRACKET, category);
        KeyMapping prev = key("prev", GLFW.GLFW_KEY_LEFT_BRACKET, category);
        KeyMapping neutral = key("neutral", GLFW.GLFW_KEY_KP_0, category);
        KeyMapping blink = key("blink", GLFW.GLFW_KEY_APOSTROPHE, category);
        KeyMapping autoBlink = key("auto_blink", GLFW.GLFW_KEY_SEMICOLON, category);
        KeyMapping reload = key("reload", GLFW.GLFW_KEY_UNKNOWN, category);

        // Отдельные клавиши на каждое выражение (цифровой блок справа, меняются в Управлении)
        Map<String, KeyMapping> direct = new LinkedHashMap<>();
        String[] names = {"happy", "sad", "surprised", "scared", "angry"};
        int[] codes = {GLFW.GLFW_KEY_KP_1, GLFW.GLFW_KEY_KP_2, GLFW.GLFW_KEY_KP_3, GLFW.GLFW_KEY_KP_4, GLFW.GLFW_KEY_KP_5};
        for (int i = 0; i < names.length; i++) {
            direct.put(names[i], key(names[i], codes[i], category));
        }

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ExpressionManager.tick(client);
            while (next.consumeClick()) ExpressionManager.cycle(client, 1);
            while (prev.consumeClick()) ExpressionManager.cycle(client, -1);
            while (neutral.consumeClick()) ExpressionManager.set(client, "neutral");
            while (blink.consumeClick()) ExpressionManager.blinkNow();
            while (autoBlink.consumeClick()) ExpressionManager.toggleAutoBlink(client);
            while (reload.consumeClick()) ExpressionManager.reload(client);
            for (Map.Entry<String, KeyMapping> e : direct.entrySet()) {
                while (e.getValue().consumeClick()) ExpressionManager.set(client, e.getKey());
            }
        });

        LOGGER.info("Face Expressions: положи свой скин (64x64) в config/expressions/base.png и нажми клавишу перезагрузки или перезапусти игру.");
    }
}
