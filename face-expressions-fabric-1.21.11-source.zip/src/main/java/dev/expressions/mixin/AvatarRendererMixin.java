package dev.expressions.mixin;

import dev.expressions.ExprHolder;
import dev.expressions.ExpressionManager;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

@Mixin(AvatarRenderer.class)
public abstract class AvatarRendererMixin {

    /** При подготовке состояния рендера запоминаем, какому игроку оно принадлежит. */
    @Inject(
        method = "extractRenderState(Lnet/minecraft/world/entity/Avatar;Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;F)V",
        at = @At("TAIL")
    )
    private void expr$extract(net.minecraft.world.entity.Avatar entity, AvatarRenderState state, float partialTick, CallbackInfo ci) {
        UUID uuid = ((Entity) (Object) entity).getUUID();
        ((ExprHolder) state).expr$setUuid(uuid);
    }

    /** Подменяем текстуру скина на нужное выражение (только для нашего игрока). */
    @Inject(
        method = "getTextureLocation(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)Lnet/minecraft/resources/Identifier;",
        at = @At("HEAD"),
        cancellable = true
    )
    private void expr$texture(AvatarRenderState state, CallbackInfoReturnable<Identifier> cir) {
        UUID uuid = ((ExprHolder) state).expr$getUuid();
        Identifier id = ExpressionManager.textureFor(uuid);
        if (id != null) {
            cir.setReturnValue(id);
        }
    }
}
