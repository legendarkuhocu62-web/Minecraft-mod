package dev.expressions.mixin;

import dev.expressions.ExprHolder;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.UUID;

@Mixin(AvatarRenderState.class)
public class AvatarRenderStateMixin implements ExprHolder {
    @Unique
    private UUID expr$uuid;

    @Override
    public void expr$setUuid(UUID uuid) {
        this.expr$uuid = uuid;
    }

    @Override
    public UUID expr$getUuid() {
        return this.expr$uuid;
    }
}
